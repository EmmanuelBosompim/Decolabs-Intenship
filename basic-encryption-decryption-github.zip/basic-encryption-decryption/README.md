# Basic Encryption & Decryption

A simple Python program that demonstrates basic text encryption and decryption using a Caesar cipher.

## Features

- Accepts text from the user
- Accepts a shift key from 1 to 25
- Encrypts uppercase and lowercase letters
- Keeps spaces, numbers, and symbols unchanged
- Decrypts the encrypted text back to the original text
- Displays the original, encrypted, and decrypted text

## How It Works

The program uses a Caesar cipher. Each letter is shifted by the number entered as the shift key.

For example, with a shift of `5`:

- `a` becomes `f`
- `b` becomes `g`
- `A` becomes `F`

The same shift is then reversed to decrypt the message.

## How to Run

Make sure Python is installed, then run:

```bash
python basic_encryption_decryption.py
```

## Example

Input:

```text
Enter the text you want to encrypt: emmanuelbosmpim
Enter the shift key (1-25): 5
```

The program displays the original text, encrypted text, and decrypted text.

## Technologies

- Python
- Caesar Cipher
